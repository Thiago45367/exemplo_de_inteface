package br.com.example.exemplo.Repositorio;

import org.springframework.stereotype.Repository;
import br.com.example.exemplo.Modelo.ProdutoModelo;
import org.springframework.data.repository.CrudRepository;



@Repository
public interface ProdutoRepositorio extends CrudRepository<ProdutoModelo, Long> {
   
    


    
}

package br.com.example.exemplo.Servico;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import br.com.example.exemplo.Repositorio.ProdutoRepositorio;
import br.com.example.exemplo.Modelo.ProdutoModelo;
import br.com.example.exemplo.Modelo.RespostaModelo;



@Service
public class ProdutoServico {
    
    @Autowired
    private ProdutoRepositorio pr;

    @Autowired
    private RespostaModelo rm;


    public Iterable<ProdutoModelo> listar() {
        return pr.findAll();
    }

    public ResponseEntity<?> cadastrarAlterar(ProdutoModelo pm, String acao) {
        if(pm.getNome().equals("")){
            rm.setMensagem("O produto não pode ser vazio");
            return new ResponseEntity<RespostaModelo>(rm,HttpStatus.BAD_REQUEST);
        }else if(pm.getMarca().equals("")){
            rm.setMensagem("A marca não pode ser vazia");
            return new ResponseEntity<RespostaModelo>(rm,HttpStatus.BAD_REQUEST);

        }else{
            if(acao.equals("cadastrar")){
            return new ResponseEntity<ProdutoModelo>(pr.save(pm),HttpStatus.CREATED);
            }else{
                return new ResponseEntity<ProdutoModelo>(pr.save(pm),HttpStatus.OK);
            }
        }
    }
}
